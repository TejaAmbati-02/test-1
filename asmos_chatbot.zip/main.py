from fastapi import FastAPI
from fastapi import Request
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import traceback
import asyncio
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import time
import sys


from asmos_buyer_assisnt_chatbot.src.routes import conversational_routes, conversational_stream_routes, feedback_routes, health_routes

#-------------------
# Create FastAPI app
#-------------------
app = FastAPI(
    title       = "ASMOS CHATBOT",
    version     = "1.0",
    description = "MCIT ServiceGen Agentic AI Chatbot",
    docs_url    = "/docs",
    redoc_url   = "/redoc",
    # lifespan    = ""
)

#----------------
# CORS Middleware
#----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins = [""],
    allow_credentials = True,
    allow_methods = ["*"],
    allow_headers = ["*"]
)

#---------------
# Include Routes
#---------------
app.include_router(conversational_routes.router, tags = ["conversations"])
app.include_router(conversational_stream_routes.router, tags = ["SSE"])
app.include_router(health_routes.router,tags=["health"])
app.include_router(feedback_routes.router,tags=["feedback"])


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",  ### "app.main:app",
        host="0.0.0.0",
        port=8000,
        # reload=settings_obj.DEBUG
    )
