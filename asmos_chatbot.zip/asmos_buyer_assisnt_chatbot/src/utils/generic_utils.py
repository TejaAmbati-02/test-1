class GenericUtils:
    def __init__(self):
        pass

    