from datetime import datetime, timezone

class DatetimeUtils:
    def __init__(self):
        pass

    def now_iso(self):
        return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


date_time_utils_obj = DatetimeUtils()

if __name__ == "__main__":
    date_time_utils_obj = DatetimeUtils()