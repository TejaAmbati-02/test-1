import os
import time
from fastapi import APIRouter, Request
import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Dict, List, Optional
 
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from asmos_buyer_assisnt_chatbot.src.utils.date_time_utils import date_time_utils_obj

router = APIRouter()


@router.post("/v1/conversations")
async def create_conversation(request: Request):
    request_json = await request.json()
    language = request_json.get("language")
    platform = request_json.get("platform")
 
    return {
        "conversation_id": str(uuid.uuid4()),
        "language": language,
        "platform": platform,
        "transaction_status": "success",
        "created_at": date_time_utils_obj.now_iso(),
    }


@router.delete("/v1/conversations")
async def delete_conversation(request: Request):
    # DELETE uses query params: ?conversation_id=...&language=en&platform=web
    conversation_id = request.query_params.get("conversation_id")
    language = request.query_params.get("language")
    platform = request.query_params.get("platform")
 
    return {
        "conversation_id": conversation_id,
        "language": language,
        "platform": platform,
        "transaction_status": "success",
        "deleted_at": date_time_utils_obj.now_iso(),
    }


@router.post("/v1/chat")
async def handle_chat(request: Request):
    form = await request.form()
    conversation_id = form.get("conversation_id")
    language = form.get("language")
    platform = form.get("platform")
    content = form.get("content")
    image = form.get("image")  # optional
 
    return {
        "conversation_id": conversation_id,
        "message_id": str(uuid.uuid4()),
        "language": language,
        "content": "complete response",
        "content_type": "text",
        "response_type": "message",
        "section": "answer",
        "transaction_status": "success",
        "timestamp": date_time_utils_obj.now_iso(),
    }
