import os
import time
from fastapi import APIRouter, Request
import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Dict, List, Optional
 
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from asmos_buyer_assisnt_chatbot.src.utils.date_time_utils import date_time_utils_obj

router = APIRouter()

@router.post("/v1/messages/feedback")
async def submit_message_feedback(request: Request):
    request_json = await request.json()
    conversation_id = request_json.get("conversation_id")
    message_id = request_json.get("message_id")
    language = request_json.get("language")
    platform = request_json.get("platform")
    feedback_val = request_json.get("feedback_val")

 
    return {
        "conversation_id": conversation_id,
        "message_id": message_id,
        "language": language,
        "platform": platform,
        "transaction_status": "success",
    }