import os
import time
from fastapi import APIRouter, Request
import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Dict, List, Optional
 
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.responses import StreamingResponse

from asmos_buyer_assisnt_chatbot.src.utils.date_time_utils import date_time_utils_obj

router = APIRouter()

@router.post("/api/v1/chat/stream/stop")
async def stop_chat_stream(request: Request):
    request_json = await request.json()
    conversation_id = request_json.get("conversation_id")
    message_id = request_json.get("message_id")
    language = request_json.get("language")
    platform = request_json.get("platform")
 
    return {
        "conversation_id": conversation_id,
        "language": language,
        "platform": platform,
        "transaction_status": "success",
        "created_at": date_time_utils_obj.now_iso(),
    }

@router.post("/v1/chat/stream")
async def handle_streaming_chat(request: Request):
    form = await request.form()
    conversation_id = form.get("conversation_id")
    language = form.get("language")
    platform = form.get("platform")
    content = form.get("content")
    image = form.get("image")  # optional
 
    message_id = str(uuid.uuid4())
 
    def event(content, content_type, response_type, section):
        payload = {
            "conversation_id": conversation_id,
            "message_id": message_id,
            "language": language,
            "content": content,
            "content_type": content_type,
            "response_type": response_type,
            "section": section,
            "transaction_status": "success",
            "timestamp": date_time_utils_obj.now_iso(),
        }
        return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
 
    async def dummy_stream():
        yield event("", "text", "start", "intro")
        yield event("Here are some products matching your request...", "text", "token", "intro")
        yield event([
            {
                "asmo_material_number": "ASMO123",
                "aramco_material_number": "ARAMCO123",
                "sku_name": "Industrial Gate Valve",
                "sku_id": "sku-123",
                "primary_image_url": "https://example.com/image.jpg",
                "temporary_unavailable": False,
                "seller_details": [
                    {"name": "seller_123", "lead_time": 3, "unit_type": "Ea", "price": 123, "moq": 5, "currency": "SAR"},
                    {"name": "seller_456", "lead_time": 5, "unit_type": "Ea", "price": 129, "moq": 10, "currency": "SAR"},
                ],
            }
        ], "json", "message", "products")
        yield event("**Why these are recommended:**\n\n", "text", "token", "recommend_reasons")
        yield event("✅ Contracted pricing, no additional approval.", "text", "token", "recommend_reasons")
        yield event("", "text", "end", "recommend_reasons")
 
    return StreamingResponse(dummy_stream(), media_type="text/event-stream")
 
