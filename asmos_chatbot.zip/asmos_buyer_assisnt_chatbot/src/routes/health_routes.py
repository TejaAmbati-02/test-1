import os
import time
from fastapi import APIRouter, Request
import asyncio
import json
import uuid
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Dict, List, Optional
 
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse

from asmos_buyer_assisnt_chatbot.src.utils.date_time_utils import date_time_utils_obj

router = APIRouter()

@router.get("/api/v1/health")
async def health_check(request: Request):
    return {
        "status": "healthy",
        "service": "asmos-chatbot",
        "version": "1.0.0",
        "timestamp": date_time_utils_obj.now_iso(),
    }


